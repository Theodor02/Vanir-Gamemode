CLASS.name = "Elite Metropolice"
CLASS.faction = FACTION_OTA
CLASS.isDefault = false
CLASS_EMP = CLASS.index