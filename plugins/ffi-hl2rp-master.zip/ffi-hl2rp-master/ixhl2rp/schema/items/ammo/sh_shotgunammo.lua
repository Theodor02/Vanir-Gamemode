ITEM.name = "Shotgun Shells"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "buckshot" -- type of the ammo
ITEM.ammoAmount = 15 -- amount of the ammo
ITEM.ammoDesc = "A Box of %s Shotgun Shells"