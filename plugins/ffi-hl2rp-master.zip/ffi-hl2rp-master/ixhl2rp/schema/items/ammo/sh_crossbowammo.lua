ITEM.name = "Crossbow Bolts"
ITEM.model = "models/Items/BoxBuckshot.mdl"
ITEM.ammo = "XBowRounds" -- type of the ammo
ITEM.ammoAmount = 5 -- amount of the ammo
ITEM.ammoDesc = "A Bundle of %s Crossbow Bolts"