
ITEM.name = "Request Device"
ITEM.model = Model("models/gibs/shield_scanner_gib1.mdl")
ITEM.description = "A box with rounded corners, housing two buttons."
ITEM.price = 20
