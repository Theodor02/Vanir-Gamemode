ITEM.name = "Empty Bottle"
ITEM.description = "An Empty Bottle."
ITEM.model = "models/props_junk/garbage_glassbottle003a.mdl"
ITEM.class = "weapon_hl2bottle"
ITEM.weaponCategory = "melee"
ITEM.width = 1
ITEM.height = 1