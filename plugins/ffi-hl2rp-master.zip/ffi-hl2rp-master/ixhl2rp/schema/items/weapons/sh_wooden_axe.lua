ITEM.name = "Crude Axe"
ITEM.description = "A Crude Axe fashioned from scrap."
ITEM.model = "models/weapons/HL2meleepack/w_axe.mdl"
ITEM.class = "weapon_hl2axe"
ITEM.weaponCategory = "melee"
ITEM.width = 3
ITEM.height = 1
ITEM.iconCam = {
	pos = Vector(334.25479125977, 279.77459716797, 203.62850952148),
	ang = Angle(25, 220, 0),
	fov = 5.2866691148943,
	outline = true,
	outlineColor = Color(255, 255, 255)
}