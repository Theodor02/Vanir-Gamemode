ATTRIBUTE.name = "Engineering"
ATTRIBUTE.description = "Affects your crafting output and skill."