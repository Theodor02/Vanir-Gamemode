ATTRIBUTE.name = "Gunsmithing"
ATTRIBUTE.description = "Affects your skill in gun related crafting."