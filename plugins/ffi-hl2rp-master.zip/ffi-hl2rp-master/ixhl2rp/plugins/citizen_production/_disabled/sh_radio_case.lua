ITEM.name = "Radio Case"
ITEM.model = "models/deadbodies/dead_male_civilian_radio.mdl"
ITEM.description = "An empty radio case."
ITEM.chance = 15
ITEM.category = "Crafting"