ITEM.name = "Sturdy Needle"
ITEM.model = "models/props_c17/trappropeller_lever.mdl"
ITEM.description = "A sturdy metal needle."
ITEM.chance = 15
ITEM.category = "Crafting"