ITEM.name = "Cinderblock"
ITEM.model = "models/props_junk/cinderblock01a.mdl"
ITEM.description = "A stone cinderblock"
ITEM.chance = 30
ITEM.category = "Crafting"