ITEM.name = "Light Bulb"
ITEM.model = "models/maxofs2d/light_tubular.mdl"
ITEM.description = "A fragile light bulb. Careful!"
ITEM.chance = 15
ITEM.category = "Crafting"