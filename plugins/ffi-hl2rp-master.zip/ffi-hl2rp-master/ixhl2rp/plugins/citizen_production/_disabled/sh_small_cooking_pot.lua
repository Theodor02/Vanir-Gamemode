ITEM.name = "Small Cooking Pot"
ITEM.model = "models/props_interiors/pot02a.mdl"
ITEM.description = "A small cooking pot."
ITEM.chance = 15
ITEM.category = "Crafting"