ITEM.name = "Empty Pill Bottle"
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.description = "An empty prescription pill bottle, the name is scratched off."
ITEM.chance = 15
ITEM.category = "Crafting"