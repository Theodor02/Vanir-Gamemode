ITEM.name = "Small Thermos"
ITEM.model = "models/bioshockinfinite/xoffee_mug_closed.mdl"
ITEM.description = "A small thermos, useful for collecting liquids."
ITEM.chance = 15
ITEM.category = "Crafting"