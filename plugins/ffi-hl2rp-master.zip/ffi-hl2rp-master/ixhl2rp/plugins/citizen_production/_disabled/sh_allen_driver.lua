ITEM.name = "Allen Driver"
ITEM.model = "models/props_c17/trappropeller_lever.mdl"
ITEM.description = "A beautiful Screwdriver."
ITEM.chance = 15
ITEM.category = "Crafting"
