ITEM.name = "Rusty Crossbow"
ITEM.model = "models/weapons/w_crossbow.mdl"
ITEM.description = "A rusty crossbow, it doesn't seem to operate but maybe after some restornation..."
ITEM.chance = 5
ITEM.category = "Crafting"