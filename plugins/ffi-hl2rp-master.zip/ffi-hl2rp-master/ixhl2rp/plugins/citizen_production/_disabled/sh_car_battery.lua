ITEM.name = "Car Battery"
ITEM.model = "models/Items/car_battery01.mdl"
ITEM.description = "A car battery."
ITEM.chance = 10
ITEM.category = "Crafting"