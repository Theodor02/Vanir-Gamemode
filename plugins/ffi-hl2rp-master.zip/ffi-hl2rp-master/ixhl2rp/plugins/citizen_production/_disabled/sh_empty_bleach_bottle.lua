ITEM.name = "Empty Bleach Bottle"
ITEM.description = "An empty bottle of bleach"
ITEM.model = "models/props_junk/garbage_plasticbottle001a.mdl"
ITEM.chance = 10
ITEM.category = "Crafting"