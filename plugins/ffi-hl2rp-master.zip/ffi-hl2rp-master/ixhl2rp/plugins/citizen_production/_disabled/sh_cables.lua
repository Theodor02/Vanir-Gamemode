ITEM.name = "Cables"
ITEM.model = "models/Items/CrossbowRounds.mdl"
ITEM.description = "A bundle of cables."
ITEM.chance = 75
ITEM.category = "Crafting"