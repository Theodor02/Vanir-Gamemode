ITEM.name = "Scrap Glass"
ITEM.model = "models/props_junk/garbage_glassbottle001a_chunk03.mdl"
ITEM.description = "A broken piece of glass."
ITEM.chance = 15
ITEM.category = "Crafting"