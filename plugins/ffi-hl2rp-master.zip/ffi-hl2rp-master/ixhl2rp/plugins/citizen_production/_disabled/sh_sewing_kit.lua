ITEM.name = "Sewing Kit"
ITEM.model = "models/props/cs_office/Cardboard_box02.mdl"
ITEM.description = "A box containing sewing needles, thread and other things for professional tailoring."
ITEM.chance = 35
ITEM.category = "Crafting"