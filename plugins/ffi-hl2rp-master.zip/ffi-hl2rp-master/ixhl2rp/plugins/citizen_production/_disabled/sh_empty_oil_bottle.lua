ITEM.name = "Empty Cooking Oil Bottle"
ITEM.model = "models/props_junk/garbage_plasticbottle002a.mdl"
ITEM.description = "An empty bottle of cooking oil"
ITEM.chance = 15
ITEM.category = "Crafting"