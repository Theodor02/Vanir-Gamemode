ITEM.name = "Rope"
ITEM.model = "models/props_lab/pipesystem03a.mdl"
ITEM.description = "A small length of rope."
ITEM.chance = 60
ITEM.category = "Crafting"