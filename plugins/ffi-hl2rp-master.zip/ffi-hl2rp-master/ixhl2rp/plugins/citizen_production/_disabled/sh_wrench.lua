ITEM.name = "Wrench"
ITEM.model = "models/props_c17/tools_wrench01a.mdl"
ITEM.description = "A heavy metal wrench."
ITEM.chance = 35
ITEM.category = "Crafting"