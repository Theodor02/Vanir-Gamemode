ITEM.name = "Small Cannister"
ITEM.model = "models/props_phx2/garbage_metalcan001a.mdl"
ITEM.description = "A small cannister, I wonder what's inside."
ITEM.chance = 15
ITEM.category = "Crafting"