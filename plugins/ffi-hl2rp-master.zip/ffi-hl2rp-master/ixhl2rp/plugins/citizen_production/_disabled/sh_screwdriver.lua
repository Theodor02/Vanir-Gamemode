ITEM.name = "Screwdriver"
ITEM.model = "models/props_c17/trappropeller_lever.mdl"
ITEM.description = "A screwdriver."
ITEM.chance = 90
ITEM.category = "Crafting"