ITEM.name = "Empty Chinese Takeout"
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"
ITEM.description = "An empty chinese takeout box."
ITEM.chance = 15
ITEM.category = "Crafting"