ITEM.name = "Chunk of Plastic"
ITEM.model = "models/props_c17/canisterchunk01a.mdl"
ITEM.description = "A medium sized chunk of plastic."
ITEM.chance = 60
ITEM.category = "Crafting"