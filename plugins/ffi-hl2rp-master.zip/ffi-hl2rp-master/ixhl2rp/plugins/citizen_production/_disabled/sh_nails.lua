ITEM.name = "Nails"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.description = "A small box of nails."
ITEM.chance = 15
ITEM.category = "Crafting"