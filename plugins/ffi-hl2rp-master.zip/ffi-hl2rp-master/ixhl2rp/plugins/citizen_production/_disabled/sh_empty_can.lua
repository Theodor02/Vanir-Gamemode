ITEM.name = "Rusty Can"
ITEM.model = "models/props_junk/garbage_metalcan002a.mdl"
ITEM.description = "A rusty can."
ITEM.chance = 15
ITEM.category = "Crafting"