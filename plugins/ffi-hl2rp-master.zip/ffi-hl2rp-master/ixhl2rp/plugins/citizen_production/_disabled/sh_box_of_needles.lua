ITEM.name = "Box of Needles"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.description = "A tiny box containing needles fit for sewing."
ITEM.chance = 35
ITEM.category = "Crafting"