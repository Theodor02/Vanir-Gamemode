ITEM.name = "Battery"
ITEM.model = "models/Items/battery.mdl"
ITEM.description = "A battery pack."
ITEM.chance = 15
ITEM.category = "Crafting"
