ITEM.name = "Rubber Tire"
ITEM.model = "models/props_vehicles/carparts_tire01a.mdl"
ITEM.description = "A rubber tire, you'd be lucky if it still had any air left."
ITEM.chance = 5
ITEM.category = "Crafting"