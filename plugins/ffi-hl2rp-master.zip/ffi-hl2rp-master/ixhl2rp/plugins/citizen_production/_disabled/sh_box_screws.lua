ITEM.name = "Box of Screws"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.description = "A tiny box containing small screws. Probably used for making something."
ITEM.chance = 35
ITEM.category = "Crafting"