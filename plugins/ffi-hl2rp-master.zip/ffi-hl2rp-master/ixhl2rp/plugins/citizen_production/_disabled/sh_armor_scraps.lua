ITEM.name = "Armor Scraps"
ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.description = "Scraps from various armor parts. Can be used to repair most armors."
ITEM.chance = 15
ITEM.category = "Crafting"