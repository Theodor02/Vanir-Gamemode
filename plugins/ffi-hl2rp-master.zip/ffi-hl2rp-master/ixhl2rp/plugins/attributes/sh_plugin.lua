PLUGIN.name = "Extra Attributes"
PLUGIN.description = "Extra Attributes to level."
PLUGIN.author = "ZeMysticalTaco"