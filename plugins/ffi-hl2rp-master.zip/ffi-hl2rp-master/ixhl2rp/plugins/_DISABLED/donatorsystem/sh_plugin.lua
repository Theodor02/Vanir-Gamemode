local PLUGIN = PLUGIN
PLUGIN.name = "Donator System"
PLUGIN.author = "ZeMysticalTaco"
PLUGIN.description = "A fully automated donator system."

//Hello developer! You're probably wondering where sv_database is! It is ignored on the git, for obvious reasons.
ix.util.Include("sv_database.lua")
ix.util.Include("sv_plugin.lua")
