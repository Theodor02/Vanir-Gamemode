# Minerva Servers HL2RP Version 0.3a

A Half-Life 2 Roleplay gamemode for Garry's Mod, built on the Helix framework. This schema was developed by Minerva Servers and used in 2022.

## Description

This is version 0.3a of the HL2RP schema, introducing new factions, weapons & base, UI improvements, fixes, features and other small updates. Relive Half-Life 2 Roleplay, but in City 8! Heavily inspired by Lite Network 2021. It features a comprehensive roleplay experience with factions, items, and various gameplay mechanics.

## Differences from Previous Versions

- **From 0.1a:** Brand new features and systems introduced, new UI overhaul
- **From 0.2a:** New factions, weapons & base, UI improvements, fixes, features and other small updates. Set in City 8 instead of City 17.

## Installation

1. Download the Helix framework from [GitHub](https://github.com/NebulousCloud/helix).
2. Place this schema folder in your Garry's Mod `garrysmod/gamemodes` directory.
3. **Note:** The required content pack (https://steamcommunity.com/sharedfiles/filedetails/?id=2884206618) is no longer available on Steam Workshop.
4. Start the server with the gamemode `minervahl2rp`.

## Requirements

- Garry's Mod
- Helix Framework
- Content pack: https://steamcommunity.com/sharedfiles/filedetails/?id=2884206618 (no longer available)

## Features

- APC spawn library
- ATM system for banking
- Achievements system
- Ambient sound environments
- Ammo saving
- Anti-AFK system
- Anti-family share protection
- Antlion faction library
- Arrest and jail mechanics
- Badges library
- Blacklisted words filter
- Body group manager
- Broadcast library
- Cassie announcements
- Chat display enhancements
- Citizen and rebel factions
- City code library
- City worker tools
- Cocaine library
- Combine HUD
- Combine ban library
- Combine faction system with various ranks and models
- Crash screen
- Custom weapons and items
- Dispatch system
- Door blasting mechanics
- Dynamic walking
- Entity information display
- Event manager
- Force field library
- Hunger and ration system
- Hunter faction library
- Interaction delays
- Item cleaner
- Item drop library
- Local events
- Logging system
- Loot library
- Media library
- Money dropping
- Music kits
- NLR (New Life Rule) library
- NPC drop library
- Necrotic effects
- No clip lighting
- Observer mode
- Outfits library
- Overwatch deployments
- PAC (Player Appearance Customizer)
- Permanent removal and classes
- Persistent corpses
- Protection teams
- Raid library
- Rank NPC interactions
- Rappelling system
- Relations system
- Safe boxes
- Scanner library
- Scenes system
- Shop terminals
- Shoving mechanics
- Skins library
- Spawn saving
- Spawner library
- Squads system
- Third person view
- Tutorial library
- Voice chat enhancements and panels
- Vortigaunt faction library
- Warning system
- Waypoints
- Weapon library
- XP library
- And many more plugins for immersive roleplay

## Configuration

Edit `schema/sh_config.lua` to customize settings like city name, currency, Discord URL, etc.

## Credits

- Developed by Minerva Servers
- Inspired by Lite Network 2021
- Built on Helix framework by Nebulous

## License

See `dejavu fonts license.txt` for font licensing information.
