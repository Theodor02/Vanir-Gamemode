local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers UI Rework"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.util.Include("cl_plugin.lua")
