local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Broadcast Library"
PLUGIN.description = ""
PLUGIN.author = "eon"

ix.util.Include("sv_plugin.lua")