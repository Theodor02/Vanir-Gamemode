
STATION.name = "Workbench"
STATION.description = "A workbench used for crafting."
STATION.model = "models/props_wasteland/controlroom_desk001b.mdl"
