ENT.Base = "base_gmodentity"
ENT.Type = "anim"
ENT.PrintName = "Shop Terminal"
ENT.Author = "Riggs"
ENT.Category = "HL2 RP"

ENT.Spawnable = true
ENT.AdminOnly = true
