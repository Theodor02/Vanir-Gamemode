local PLUGIN = PLUGIN

ITEM.name = "Packaged Coca Seed"
ITEM.description = ""
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.category = "Cocaine Laboratory"
ITEM.width = 1
ITEM.height = 1

ITEM.price = 5

ITEM.deployableRange = 96
ITEM.deployableEntity = "ecl_seed"