ENT.Type            = "anim"
ENT.Base            = "base_gmodentity"

ENT.PrintName       = "Rubble"
ENT.Category        = "HL2 RP"
ENT.Author          = "Silhouhat"
ENT.Contact 	    = "contact@silhouhat.com"

ENT.Spawnable   	= false