ITEM.name = "Box of Explosives"
ITEM.description = "Manufactured on a crafting table, home-made explosives, they are fragile and effective for bombs of course."
ITEM.category = "Stackables"
ITEM.model = "models/props_junk/cardboard_box004a.mdl"
ITEM.illegal = true

ITEM.maxStacks = 16