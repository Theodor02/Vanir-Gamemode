ITEM.name = "Aid Fluid"
ITEM.description = "A bottle of Aid Fluid, it's contents are from antlion grubs."
ITEM.category = "Stackables"
ITEM.model = "models/props_junk/glassjug01.mdl"

ITEM.maxStacks = 24