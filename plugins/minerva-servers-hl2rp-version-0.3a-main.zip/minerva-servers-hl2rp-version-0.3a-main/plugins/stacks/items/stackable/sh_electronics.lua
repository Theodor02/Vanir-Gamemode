ITEM.name = "Electronics"
ITEM.description = "Some electronic parts."
ITEM.category = "Stackables"
ITEM.model = "models/props/cs_office/projector_p6.mdl"
ITEM.illegal = true

ITEM.maxStacks = 16