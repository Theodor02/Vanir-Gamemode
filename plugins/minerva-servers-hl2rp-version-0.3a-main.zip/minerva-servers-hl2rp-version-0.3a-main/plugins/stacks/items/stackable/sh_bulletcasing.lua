ITEM.name = "Bullet Casing"
ITEM.description = "A metal casing for bullets."
ITEM.category = "Stackables"
ITEM.model = "models/items/ar2_grenade.mdl"
ITEM.illegal = true

ITEM.maxStacks = 32