ITEM.name = "Piece of Cloth"
ITEM.description = "A piece of cloth."
ITEM.category = "Stackables"
ITEM.material = "models/props_c17/FurnitureFabric003a"
ITEM.model = "models/props_junk/garbage_newspaper001a.mdl"

ITEM.maxStacks = 64