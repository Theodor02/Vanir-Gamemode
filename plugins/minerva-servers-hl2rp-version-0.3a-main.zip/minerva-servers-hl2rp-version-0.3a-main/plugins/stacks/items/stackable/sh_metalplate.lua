ITEM.name = "Metal Plate"
ITEM.description = "A metal plate."
ITEM.category = "Stackables"
ITEM.model = "models/gibs/metal_gib4.mdl"

ITEM.maxStacks = 32