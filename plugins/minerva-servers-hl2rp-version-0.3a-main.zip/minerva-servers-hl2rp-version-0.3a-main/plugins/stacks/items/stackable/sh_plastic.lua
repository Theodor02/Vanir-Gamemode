ITEM.name = "Chunk of Plastic"
ITEM.description = "A small chunk of scrap plastic."
ITEM.category = "Stackables"
ITEM.model = "models/props_c17/canisterchunk01a.mdl"

ITEM.maxStacks = 20