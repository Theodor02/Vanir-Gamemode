ITEM.name = "Metal Gear"
ITEM.description = "A small metal gear."
ITEM.category = "Stackables"
ITEM.model = "models/props_wasteland/gear02.mdl"

ITEM.maxStacks = 16