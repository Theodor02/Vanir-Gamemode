ITEM.name = "Metal Pipe"
ITEM.description = "A metal pipe."
ITEM.category = "Stackables"
ITEM.model = "models/props_lab/pipesystem03a.mdl"

ITEM.maxStacks = 16