ITEM.name = "Destroyed Biolink"
ITEM.description = "An Destroyed Biolink from an Metropolice Unit."
ITEM.category = "Stackables"
ITEM.model = "models/gibs/manhack_gib03.mdl"
ITEM.illegal = true

ITEM.maxStacks = 16