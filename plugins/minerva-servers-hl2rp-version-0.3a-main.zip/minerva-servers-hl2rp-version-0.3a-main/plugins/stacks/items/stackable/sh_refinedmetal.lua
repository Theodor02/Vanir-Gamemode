ITEM.name = "Refined Metal Plate"
ITEM.description = "A refined metal plate."
ITEM.category = "Stackables"
ITEM.model = "models/gibs/scanner_gib02.mdl"
ITEM.illegal = true

ITEM.maxStacks = 24