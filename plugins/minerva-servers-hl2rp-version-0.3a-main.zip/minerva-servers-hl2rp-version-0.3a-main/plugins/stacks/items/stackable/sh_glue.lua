ITEM.name = "Glue"
ITEM.description = "A tube with sticky liquid."
ITEM.category = "Stackables"
ITEM.model = "models/items/battery.mdl"

ITEM.maxStacks = 32