ITEM.name = "Wood"
ITEM.description = "A piece of wood."
ITEM.category = "Stackables"
ITEM.model = "models/gibs/wood_gib01e.mdl"

ITEM.maxStacks = 32