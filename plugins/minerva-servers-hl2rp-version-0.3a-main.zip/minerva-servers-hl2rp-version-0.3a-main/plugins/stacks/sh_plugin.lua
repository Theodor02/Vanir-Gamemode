
PLUGIN.name = "Stackable Items"
PLUGIN.description = "Adds the ability to stack items in one"
PLUGIN.author = "Bilwin"
PLUGIN.schema = "Any"
PLUGIN.version = 1.0

ix.util.Include("sh_meta.lua")