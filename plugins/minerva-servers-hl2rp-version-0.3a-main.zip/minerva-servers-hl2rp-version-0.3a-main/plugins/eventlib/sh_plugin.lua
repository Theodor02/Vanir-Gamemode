local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Event Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.event = ix.event or {}

ix.util.Include("cl_plugin.lua")
ix.util.Include("sv_plugin.lua")
