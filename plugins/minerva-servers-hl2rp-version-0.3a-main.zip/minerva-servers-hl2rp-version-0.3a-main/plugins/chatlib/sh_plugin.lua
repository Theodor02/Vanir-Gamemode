local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Chat Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.util.Include("sh_chatbox.lua")
