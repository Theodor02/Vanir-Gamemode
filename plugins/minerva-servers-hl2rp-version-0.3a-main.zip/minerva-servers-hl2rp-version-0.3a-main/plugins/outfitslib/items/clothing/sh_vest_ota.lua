ITEM.name = "Overwatch Vest"
ITEM.description = "A fixed Overwatch Vest, it can be used to protect yourself from damage."
ITEM.category = "Clothing"
ITEM.model = "models/nemez/combine_soldiers/combine_soldier_prop_vest.mdl"
ITEM.outfitCategory = "Vest"

ITEM.bodyGroups = {
    ["kevlar"] = 5
}

ITEM.allowedModels = {
    "models/hl2rp/male_01.mdl",
    "models/hl2rp/male_02.mdl",
    "models/hl2rp/male_03.mdl",
    "models/hl2rp/male_04.mdl",
    "models/hl2rp/male_05.mdl",
    "models/hl2rp/male_06.mdl",
    "models/hl2rp/male_07.mdl",
    "models/hl2rp/male_08.mdl",
    "models/hl2rp/male_09.mdl",
    "models/hl2rp/female_01.mdl",
    "models/hl2rp/female_02.mdl",
    "models/hl2rp/female_03.mdl",
    "models/hl2rp/female_04.mdl",
    "models/hl2rp/female_06.mdl",
    "models/hl2rp/female_07.mdl",
}