local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Outfits Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"
