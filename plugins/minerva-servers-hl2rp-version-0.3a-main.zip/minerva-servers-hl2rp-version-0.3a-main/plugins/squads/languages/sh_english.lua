
LANGUAGE = {
	SquadName = "Squad-%s",
	SquadStatus = "Squad-%s %s",

	SquadMemberStatus = "Member",
	SquadOwnerStatus = "Leader",

	tabSquad = "Squads",
	tabCreateSquad = "Create Squad",
	tabJoinSquad = "Join Squad",
	tabLeaveSquad = "Leave Squad",

	SquadTransferOwner = "Transfer Lead",
	SquadKickMember = "Kick Member",
	SquadReassign = "Reassign Index",

	CannotUseSquadCommands = "You cannot use Squad commands!",
	CannotPromoteSquadMembers = "You cannot promote Squad members!",
	CannotKickSquadMembers = "You cannot kick Squad members!",
	CannotReassignSquadIndex = "You cannot reassign the Squad index!",

	NoCurrentSquad = "You are not apart of a Squad!",
	TargetNoCurrentSquad = "The person you are trying to promote is not apart of a Squad!",
	TargetNotSameSquad = "The person you are trying to promote is not apart of the same Squad!",

	SquadMustClamp = "You must provide a number between 1-99!",
	SquadMustLeave = "You must leave your current Squad before joining a new one!",

	SquadAlreadyHasOwner = "There is already a Squad lead!",
	SquadAlreadyExists = "A Squad with index '%s' already exists!",
	SquadNonExistent = "Squad '%s' doesn't exist!",
	AlreadyHasSquad = "You are already apart of a Squad!",

	KickedFromSquad = "You've kicked %s from the Squad.",
	SquadCreated = "Squad '%s' successfully created.",
	SquadReassigned = "Squad '%s' successfully reassigned to '%s'.",
	SquadOwnerSet = "The new Squad lead has been set to %s.",
	SquadOwnerAssume = "You've assumed Squad lead.",
	JoinedSquad = "Successfully joined Squad '%s'.",
	LeftSquad = "Successfully left Squad '%s'.",

	cmdCreateSquadDesc = "Enter the number index for your new Squad. (1-99)",
	cmdReassignSquadDesc = "Enter a new number index for your current Squad. (1-99)",
	cmdSquadCreate = "Create a Squad.",
	cmdSquadLeave = "Leave your current Squad.",
	cmdSquadLead = "Promote a Squad member to Squad lead or assume the lead position.",
	cmdSquadKick = "Kick a Squad member.",
	cmdSquadReassign = "Reassign Squad number index.",
	cmdSquadJoin = "Join a Squad."
}
