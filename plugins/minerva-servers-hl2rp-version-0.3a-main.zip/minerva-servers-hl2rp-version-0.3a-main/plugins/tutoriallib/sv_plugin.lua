local PLUGIN = PLUGIN

/*util.AddNetworkString("ixTutorialMessage")

function PLUGIN:PrePlayerLoadedCharacter(ply)
    net.Start("ixTutorialMessage")
    net.Send(ply)
end*/