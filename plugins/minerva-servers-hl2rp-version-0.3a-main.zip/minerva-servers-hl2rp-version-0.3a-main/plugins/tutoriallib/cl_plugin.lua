local PLUGIN = PLUGIN

/*net.Receive("ixTutorialMessage", function()
    Derma_Query("Are you new to our server and the helix engine?", "Minerva Servers: Tutorials", "Yes", nil, "No", nil)
end)*/