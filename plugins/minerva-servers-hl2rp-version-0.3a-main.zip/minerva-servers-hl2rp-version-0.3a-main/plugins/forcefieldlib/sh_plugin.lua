local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Forcefield Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.util.Include("sv_plugin.lua")
