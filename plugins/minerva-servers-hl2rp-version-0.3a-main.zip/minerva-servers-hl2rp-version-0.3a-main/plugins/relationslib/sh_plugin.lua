local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Relations Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.relations = ix.relations or {}

ix.util.Include("sv_plugin.lua")
