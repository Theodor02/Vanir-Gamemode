ITEM.name = "Beans"
ITEM.description = "A metal can, it's contents are filled with beans."
ITEM.category = "Food"
ITEM.model = "models/props_junk/garbage_metalcan002a.mdl"

ITEM.useTime = 2
ITEM.useSound = "minerva/global/eat.mp3"
ITEM.restoreHunger = 40

ITEM.price = 40
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK