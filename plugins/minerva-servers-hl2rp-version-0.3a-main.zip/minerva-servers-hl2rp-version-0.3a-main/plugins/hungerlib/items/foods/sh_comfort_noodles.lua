ITEM.name = "Noodles"
ITEM.description = "A Takeout carton halfway filled with Noodles."
ITEM.category = "Food"
ITEM.model = "models/props_junk/garbage_takeoutcarton001a.mdl"

ITEM.useTime = 1.5
ITEM.useSound = "minerva/global/eat.mp3"
ITEM.restoreHunger = 40

ITEM.price = 40
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK