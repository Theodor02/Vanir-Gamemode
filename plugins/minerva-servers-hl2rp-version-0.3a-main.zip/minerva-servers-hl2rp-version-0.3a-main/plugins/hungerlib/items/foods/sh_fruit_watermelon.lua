ITEM.name = "Watermelon"
ITEM.description = "A big sized green fruit, some say it can be used to craft supplements."
ITEM.category = "Food"
ITEM.model = "models/props_junk/watermelon01.mdl"

ITEM.width = 2
ITEM.height = 2

ITEM.useTime = 4
ITEM.useSound = "minerva/global/eat.mp3"
ITEM.restoreHunger = 100

ITEM.price = 100
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK