ITEM.name = "Breen's Special Water"
ITEM.description = "An Alluminium canned water."
ITEM.category = "Food"
ITEM.model = "models/props_junk/PopCan01a.mdl"

ITEM.useTime = 1
ITEM.useSound = "minerva/global/drink.mp3"
ITEM.restoreHunger = 30

ITEM.skin = 2

ITEM.price = 30
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK