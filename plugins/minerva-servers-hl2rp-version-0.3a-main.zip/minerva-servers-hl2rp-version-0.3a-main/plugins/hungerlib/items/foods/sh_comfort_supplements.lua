ITEM.name = "Supplements"
ITEM.description = "A white jar filled with water & nutrition, able to sustain a human."
ITEM.category = "Food"
ITEM.model = "models/props_lab/jar01b.mdl"

ITEM.useTime = 2
ITEM.useSound = "minerva/global/eat.mp3"
ITEM.restoreHunger = 60

ITEM.price = 60
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK