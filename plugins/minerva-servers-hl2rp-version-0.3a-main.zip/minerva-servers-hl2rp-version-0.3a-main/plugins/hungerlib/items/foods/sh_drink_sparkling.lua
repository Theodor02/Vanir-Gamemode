ITEM.name = "Breen's Sparkling Water"
ITEM.description = "An Alluminium canned water."
ITEM.category = "Food"
ITEM.model = "models/props_junk/PopCan01a.mdl"

ITEM.useTime = 1
ITEM.useSound = "minerva/global/drink.mp3"
ITEM.restoreHunger = 20

ITEM.skin = 1

ITEM.price = 20
ITEM.shopTerminalBuyable = true
ITEM.shopTerminalRequiredClass = CLASS_CWU_COOK