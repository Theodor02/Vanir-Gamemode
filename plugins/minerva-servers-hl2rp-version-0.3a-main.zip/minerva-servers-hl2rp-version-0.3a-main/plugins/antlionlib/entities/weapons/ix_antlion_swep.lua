AddCSLuaFile()

SWEP.Base = "ls_base_melee"

SWEP.PrintName = "Antlion Claws"
SWEP.Category = "HL2 RP"

SWEP.Spawnable = true
SWEP.AdminOnly = true

SWEP.HoldType = "normal"

SWEP.WorldModel = ""
SWEP.ViewModel = "models/weapons/c_arms_citizen.mdl"
SWEP.ViewModelFOV = 50

SWEP.Slot = 1
SWEP.SlotPos = 1

SWEP.CSMuzzleFlashes = false

SWEP.Primary.Sound = "NPC_Antlion.MeleeAttackSingle"
SWEP.Primary.ImpactSound = "NPC_Antlion.MeleeAttack"
SWEP.Primary.Recoil = 20
SWEP.Primary.Damage = 55
SWEP.Primary.NumShots = 1
SWEP.Primary.HitDelay = 0.3
SWEP.Primary.Delay = 3
SWEP.Primary.Range = 96
SWEP.Primary.StunTime = 2