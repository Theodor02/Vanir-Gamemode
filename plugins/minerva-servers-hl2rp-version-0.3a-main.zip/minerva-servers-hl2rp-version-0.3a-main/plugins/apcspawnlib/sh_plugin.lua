local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers APC Library"
PLUGIN.description = ""
PLUGIN.author = "eon"

PLUGIN.maps = {
    ["rp_minerva_city8"] = {Vector(-3504.951904, 8566.248047, 24.779406), Angle(0, 90, 0)},
    ["rp_city24_v3"] = {Vector(5370.7456054688, 5353.3334960938, 194.03125), Angle(0, 90, 0)},
}

ix.util.Include("sv_plugin.lua")