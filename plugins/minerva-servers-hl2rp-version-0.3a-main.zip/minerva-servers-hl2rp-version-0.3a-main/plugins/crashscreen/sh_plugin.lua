local PLUGIN = PLUGIN

PLUGIN.name = "Crash Screen"
PLUGIN.description = "A Simple Crash Screen, ported from the impulse framework."
PLUGIN.author = "Riggs & vingard"

ix.util.Include("cl_plugin.lua")

// I take no credit for this.
