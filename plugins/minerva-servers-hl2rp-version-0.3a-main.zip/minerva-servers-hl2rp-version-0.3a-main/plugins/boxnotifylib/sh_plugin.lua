local PLUGIN = PLUGIN

PLUGIN.name = "Minerva Servers Box Notify Library"
PLUGIN.description = ""
PLUGIN.author = "Riggs"

ix.boxNotify = ix.boxNotify or {}

ix.util.Include("cl_plugin.lua")
ix.util.Include("sv_plugin.lua")
