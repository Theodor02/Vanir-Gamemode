LANGUAGE = {
	antiafk = "Anti-AFK",
	kickedAFK = "%s has been auto-kicked by the server (AFK)",
	kickedAdminAFK = "%s has auto-kicked '%s' (AFK).",
	charAFK = "Away from keyboard"
}